package com.farm.scripts.zulrahkiller.bank;

public class BankItem {
    public String itemName;
    public int amount;

    public BankItem(String itemName, int amount) {
        this.itemName = itemName;
        this.amount = amount;
    }
}
